-- DB Final Project Skeleton
-- Student Name: 김희곤
-- Student ID: 2126086

-- 1. CREATE TABLE

CREATE TABLE class_code (
    code INT PRIMARY KEY,
    class_name VARCHAR(20),
    basis VARCHAR(50)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(50)
);

-- TODO: customer
create table customer (
	customer_id varchar(15) primary key, 
	customer_name varchar(20) not null, 
	phone char(11) unique not null, 
	address varchar(100), 
	c_code int default 3, 
	foreign key (c_code)
	references class_code(code)
);

-- TODO: staff
create table staff (
	staff_id int primary key, 
	staff_name varchar(20) not null, 
	birthday char(6) not null, 
	phone char(11), 
	salary int, 
	t_code int not null, 
	hire_date char(8) not null, 
	foreign key (t_code)
	references task_code(code)
);

-- TODO: tour
create table tour (
	tour_id char(8) primary key, 
	staff_id int, 
	program varchar(100), 
	departure varchar(50) not null, 
	arrival varchar(50) not null, 
	start_date date not null, 
	end_date date not null, 
	min_people int, 
	max_people int,
	expense int not null, 
	deposit int, 
	depart_yn char(1) default 'n', 
	foreign key (staff_id)
	references staff(staff_id)
);

-- TODO: reserve
create table reserve (
	customer_id varchar(15), 
	tour_id char(8), 
	reserve_date date default current_date, 
	deposit_yn char(1) default 'n', 
	expense_yn char(1) default 'n',
	primary key (
		customer_id, 
		tour_id
	), 
	foreign key (customer_id)
	references customer(customer_id), 

	foreign key (tour_id)
	references tour(tour_id)
);

create table driver (
	driver_id int primary key, 
	driver_name varchar(20) not null, 
	birthday char(6) not null, 
	phone char(11) not null, 
	pay int default 20000, 
	contract_date char(8), 
	contract_term char(8)
);

create table tour_bus (
	bus_id int primary key, 
	seat int, 
	del_year int
);

create table assign_driver (
	tour_id char(8), 
	driver_id int, 
	work_hour int, 
	primary key (tour_id), 
	foreign key(tour_id)
	references tour(tour_id), 

	foreign key(driver_id)
	references driver(driver_id)
);

create table assign_bus(
	tour_id char(8), 
	bus_id int, 
	primary key(tour_id), 
	foreign key (tour_id)
	references tour(tour_id), 
	foreign key (bus_id)
	references tour_bus(bus_id)
);

-- 2. INSERT DATA

insert into class_code values
(1, '최우수', '누적 500만원 이상'),
(2, '우수', '누적 200만원 이상'),
(3, '일반', '기본 고객');

insert into task_code values
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

insert into customer values
('user01','김민수','01011111111','서울',1),
('user02','이서연','01022222222','부산',2),
('user03','박지훈','01033333333','대전',3),
('user04','최유진','01044444444','인천',2),
('user05','정도현','01055555555','광주',3);

insert into staff values
(10001,'김부장','850210','01011112222',4200000,1,'20200103'),
(10002,'이과장','880503','01022223333',3800000,2,'20210214'),
(10003,'박대리','900725','01033334444',3500000,3,'20220305'),
(10004,'최주임','950210','01044445555',3200000,4,'20230410'),
(10005,'정사원','980315','01055556666',3000000,5,'20240111');

insert into tour values
('T0000001',
10001,
'제주 2박3일',
'서울',
'제주',
'2026-07-01',
'2026-07-03',
10,
30,
500000,
100000,
'n'
),
(
'T0000002',
10002,
'부산 여행',
'서울',
'부산',
'2026-08-01',
'2026-08-03',
15,
40,
450000,
90000,
'n'
),
(
'T0000003',
10003,
'강릉 여행',
'대전',
'강릉',
'2026-07-10',
'2026-07-12',
8,
25,
390000,
70000,
'n'
),
(
'T0000004',
10004,
'여수 여행',
'인천',
'여수',
'2026-09-01',
'2026-09-03',
10,
30,
410000,
80000,
'n'
),
(
'T0000005',
10005,
'경주 여행',
'광주',
'경주',
'2026-10-01',
'2026-10-03',
12,
35,
430000,
85000,
'n'
);

insert into reserve values
('user01','T0000001','2026-06-01','y','n'),
('user02','T0000002','2026-06-02','n','n'),
('user03','T0000003','2026-06-03','y','y'),
('user04','T0000004','2026-06-04','n','n'),
('user05','T0000005','2026-06-05','y','n');

insert into driver values
(1,'홍기사','810101','01077771111',20000,'20260101','12개월'),
(2,'김기사','820202','01077772222',20000,'20260101','12개월'),
(3,'이기사','830303','01077773333',20000,'20260101','12개월'),
(4,'박기사','840404','01077774444',20000,'20260101','12개월'),
(5,'최기사','850505','01077775555',20000,'20260101','12개월');

insert into tour_bus values
(1,45,2022),
(2,40,2021),
(3,28,2023),
(4,35,2020),
(5,50,2024);

insert into assign_driver values
('T0000001',1,8),
('T0000002',2,7),
('T0000003',3,6),
('T0000004',4,9),
('T0000005',5,8);

insert into assign_bus values
('T0000001',1),
('T0000002',2),
('T0000003',3),
('T0000004',4),
('T0000005',5);

-- 3. INDEX

create index tour_arrival_idx
on tour(arrival);

create index driver_name_idx
on driver(driver_name);

-- 4. TEST QUERIES

-- Customer Grade Search
select customer_name, class_name
from customer c
join class_code cc
on c.c_code=cc.code
where customer_id='user01';

-- Employee Task Search
select staff_name, task
from staff s
join task_code t
on s.t_code=t.code
where staff_id=10001;

-- Tour Reservation Search
select customer_name, reserve_date, deposit_yn
from reserve r
join customer c
on r.customer_id=c.customer_id
where tour_id='T0000001';

-- Assigned Driver Search
select departure, driver_name,d.phone
from tour t
join assign_driver ad
on t.tour_id=ad.tour_id
join driver d
on ad.driver_id=d.driver_id
where t.tour_id='T0000001';

-- INSERT example
insert into customer
values(
'user06',
'한지민',
'01066666666',
'서울',
3
);

-- UPDATE example
update staff
set salary=salary+200000
where staff_id=10001;

-- DELETE example
delete from reserve
where customer_id='user01'
and tour_id='T0000001';
